=== Uthr===
Contributors: ThemesHub
Requires at least: 5.0
Tested up to: 5.7.2
Requires PHP: 7.3
License: GNU General Public License v2 or later
License URI: LICENSE

This theme, like WordPress, is licensed under the GPL.
Use it to make something cool, have fun, and share what you've learned with others.

== Description ==
Uthr is a Fully Responsive WordPress Theme is the best furniture shop service theme for creating a productive, splendid, and cozy website. This is highly customizable – looks awesome on tablets and mobile devices.